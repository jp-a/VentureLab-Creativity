Thanks for Downloading OOcharts!

There are some additonal resources you should know about.

List of Metrics and Dimensions: https://developers.google.com/analytics/devguides/reporting/core/dimsmets

Google Visualization Documentation for Options (Line, Pie, Table): https://developers.google.com/chart/interactive/docs/gallery

Happy Coding! If you have any questions or concerns, contact me.

-Tyler Shaddix (support@oocharts.org)